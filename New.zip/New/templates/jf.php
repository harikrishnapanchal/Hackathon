<?php
// DB Connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "SELECT * FROM products ORDER BY id DESC";
$result = $conn->query($sql);
$products = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) $products[] = $row;
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Fashion Collection</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
  <style>
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 20px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body class="bg-gray-100">

<header class="bg-green-500 text-white py-8 shadow">
  <div class="container mx-auto text-center">
    <h1 class="text-4xl font-bold">Fashion Collection</h1>
  </div>
</header>

<main class="container mx-auto px-4 py-10">
  <?php if (count($products) > 0): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      <?php foreach ($products as $product): ?>
        <?php
          $category = strtolower($product['tags']);
          $color = match($category) {
            'men' => 'bg-blue-500',
            'women' => 'bg-pink-500',
            'kids' => 'bg-yellow-500',
            default => 'bg-green-500',
          };
          $image = !empty($product['image_url']) ? $product['image_url'] : 'https://via.placeholder.com/400x300?text=No+Image';
        ?>
        <div class="card bg-white rounded-xl overflow-hidden shadow-md transition duration-300">
          <div class="relative h-48 overflow-hidden">
            <img src="<?= htmlspecialchars($image) ?>" alt="<?= htmlspecialchars($product['name']) ?>"
                 class="w-full h-full object-cover hover:scale-105 transition duration-300">
            <div class="absolute bottom-0 left-0 right-0 <?= $color ?> bg-opacity-90 text-white px-4 py-2">
              <span class="text-sm font-semibold uppercase"><?= htmlspecialchars($category) ?></span>
            </div>
          </div>
          <div class="p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($product['name']) ?></h3>
            <p class="text-gray-600 mb-4"><?= htmlspecialchars($product['description']) ?></p>
            <div class="flex items-center text-gray-500 mb-4">
              <i class="fas fa-map-marker-alt mr-2"></i>
              <span><?= htmlspecialchars($product['location']) ?></span>
            </div>
            <div class="flex justify-between items-center">
              <a href="f.php?id=<?= $product['id'] ?>" class="text-green-600 hover:text-green-800 font-medium">
                View Details <i class="fas fa-arrow-right ml-1"></i>
              </a>
              <div class="flex space-x-2">
                <i class="fab fa-facebook-f text-gray-400 hover:text-blue-500 cursor-pointer"></i>
                <i class="fab fa-twitter text-gray-400 hover:text-blue-400 cursor-pointer"></i>
                <i class="fab fa-instagram text-gray-400 hover:text-pink-500 cursor-pointer"></i>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php else: ?>
    <div class="text-center py-20">
      <i class="fas fa-search text-6xl text-gray-400 mb-4"></i>
      <h3 class="text-2xl font-semibold text-gray-700">No products found</h3>
      <p class="text-gray-500 mt-2">Please add items to your database to see them here.</p>
    </div>
  <?php endif; ?>
</main>

<footer class="bg-gray-800 text-white py-6">
  <div class="container mx-auto text-center">
    <p>&copy; <?= date('Y') ?> Fashion Collection. All rights reserved.</p>
  </div>
</footer>

</body>
</html>
