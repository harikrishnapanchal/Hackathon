        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>EcoList - Green Product Listing</title>
            <script src="https://cdn.tailwindcss.com"></script>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
            <style>
                .gradient-bg {
                    background: linear-gradient(135deg, #f0fff4 0%, #e6fffa 100%);
                }
                .product-card:hover {
                    transform: translateY(-5px);
                    box-shadow: 0 10px 25px -5px rgba(16, 185, 129, 0.2);
                }
                .green-shadow {
                    box-shadow: 0 4px 6px -1px rgba(16, 185, 129, 0.2), 0 2px 4px -1px rgba(16, 185, 129, 0.1);
                }
                .location-pin::before {
                    content: "\f3c5";
                    font-family: "Font Awesome 6 Free";
                    font-weight: 900;
                    margin-right: 5px;
                }
                .file-input-wrapper {
                    position: relative;
                    overflow: hidden;
                    display: inline-block;
                    width: 100%;
                }
                .file-input-wrapper input[type=file] {
                    position: absolute;
                    left: 0;
                    top: 0;
                    opacity: 0;
                    width: 100%;
                    height: 100%;
                    cursor: pointer;
                }
                .preview-image {
                    max-height: 200px;
                    object-fit: contain;
                    margin-top: 10px;
                    border-radius: 8px;
                    display: none;
                }
                .tag {
                    display: inline-flex;
                    align-items: center;
                    background-color: #d1fae5;
                    color: #065f46;
                    padding: 0.25rem 0.75rem;
                    border-radius: 9999px;
                    font-size: 0.875rem;
                    margin-right: 0.5rem;
                    margin-bottom: 0.5rem;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                .tag:hover {
                    background-color: #a7f3d0;
                }
                .tag.selected {
                    background-color: #34d399;
                    color: white;
                }
                .tag-remove {
                    margin-left: 0.25rem;
                    cursor: pointer;
                }
                .tag-input-container {
                    position: relative;
                }
                .tag-suggestions {
                    position: absolute;
                    top: 100%;
                    left: 0;
                    right: 0;
                    background: white;
                    border: 1px solid #d1d5db;
                    border-radius: 0.375rem;
                    z-index: 10;
                    max-height: 200px;
                    overflow-y: auto;
                    display: none;
                }
                .tag-suggestion {
                    padding: 0.5rem 1rem;
                    cursor: pointer;
                }
                .tag-suggestion:hover {
                    background-color: #f3f4f6;
                }
            </style>
        </head>
        <body class="gradient-bg min-h-screen">
            <div class="container mx-auto px-4 py-8">
                
                <header class="mb-12 text-center">
                    <h1 class="text-4xl font-bold text-green-800 mb-2">EcoList</h1>
                    <p class="text-green-600">List your sustainable products with our green marketplace</p>
                    <div class="w-24 h-1 bg-green-500 mx-auto mt-4 rounded-full"></div>
                </header>


                <!-- Product Form -->
                <div class="bg-white rounded-xl p-6 mb-12 green-shadow max-w-2xl mx-auto">
                    <h2 class="text-2xl font-semibold text-green-800 mb-6">Add New Product</h2>
                    <form id="productForm" class="space-y-4" method="POST" enctype="multipart/form-data">
                        <div>
                            <label for="productName" class="block text-green-700 mb-2">Product Name</label>
                            <input type="text" id="productName" name="productName" required
                                class="w-full px-4 py-2 border border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500">
                        </div>

                        <div>
                            <label for="productImage" class="block text-green-700 mb-2">Product Image</label>
                            <div class="file-input-wrapper">
                                <button type="button" class="w-full bg-green-100 hover:bg-green-200 text-green-700 font-medium py-2 px-4 rounded-lg transition duration-300 flex items-center justify-center">
                                    <i class="fas fa-camera mr-2"></i> Choose Image
                                </button>
                                <input type="file" id="productImage" name="productImage" accept="image/*" required
                                    class="w-full">
                            </div>
                            <img id="imagePreview" class="preview-image" alt="Image preview">
                        </div>

                        <div>
                            <label for="productDescription" class="block text-green-700 mb-2">Description</label>
                            <textarea id="productDescription" name="productDescription" rows="3" required
                                class="w-full px-4 py-2 border border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"></textarea>
                        </div>

                        <div>
                            <label for="productLocation" class="block text-green-700 mb-2">Location</label>
                            <div class="relative">
                                <input type="text" id="productLocation" name="productLocation" required
                                    class="w-full px-4 py-2 pl-10 border border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                                    placeholder="City, Country">
                                <i class="fas fa-map-marker-alt absolute left-3 top-3 text-green-500"></i>
                            </div>
                        </div>

                        <div>
                            <label class="block text-green-700 mb-2">Tags</label>
                            <div class="flex flex-wrap mb-2" id="selectedTagsContainer"></div>
                            
                            <div class="tag-input-container">
                                <input type="text" id="tagInput" name="tagInput"
                                    class="w-full px-4 py-2 border border-green-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
                                    placeholder="Type to search or add tags">
                                <div class="tag-suggestions" id="tagSuggestions"></div>
                            </div>
                            <input type="hidden" id="productTags" name="productTags">
                        </div>

                        <button type="submit" name="submit"
                            class="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition duration-300 flex items-center justify-center">
                            <i class="fas fa-leaf mr-2"></i> Add Product
                        </button>
                    </form>
                </div>

                <!-- Product Listing -->
                <div class="mb-8">
                    <h2 class="text-2xl font-semibold text-green-800 mb-6 text-center">Our Green Products</h2>
                    <div id="productList" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php
                        // Database connection
                        $servername = "localhost";
                        $username = "root"; // Change to your database username
                        $password = ""; // Change to your database password
                        $dbname = "project"; // Changed to your database name

                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Process form submission
                        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["submit"])) {
                            $productName = $_POST["productName"];
                            $productDescription = $_POST["productDescription"];
                            $productLocation = $_POST["productLocation"];
                            $productTags = $_POST["productTags"];

                            // Handle file upload
                            $targetDir  = "C:/xampp/htdocs/New/templates/uploads/";
                            if (!file_exists($targetDir)) {
                                mkdir($targetDir, 0777, true);
                            }
                            
                            $fileName = basename($_FILES["productImage"]["name"]);
                            $targetFilePath = $targetDir . $fileName;
                            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

                            // Allow certain file formats
                            $allowTypes = array('jpg','png','jpeg','gif');
                            if (in_array($fileType, $allowTypes)) {
                                // Upload file to server
                                if (move_uploaded_file($_FILES["productImage"]["tmp_name"], $targetFilePath)) {
                                    // Insert into database
                                    $sql = "INSERT INTO products (name, description, location, tags, image_path) 
                                            VALUES ('$productName', '$productDescription', '$productLocation', '$productTags', '$targetFilePath')";
                                    
                                    if ($conn->query($sql) === TRUE) {
                                        echo '<div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                                                <span class="block sm:inline">Product added successfully!</span>
                                            </div>';
                                    } else {
                                        echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                                                <span class="block sm:inline">Error: ' . $conn->error . '</span>
                                            </div>';
                                    }
                                } else {
                                    echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                                            <span class="block sm:inline">Sorry, there was an error uploading your file.</span>
                                        </div>';
                                }
                            } else {
                                echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                                        <span class="block sm:inline">Sorry, only JPG, JPEG, PNG & GIF files are allowed.</span>
                                    </div>';
                            }
                        }

                $imagePaths = []; // Store image paths

                // Fetch products from database
                $sql = "SELECT * FROM products ORDER BY id DESC";
                $result = $conn->query($sql);

                if ($result && $result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        $tags = explode(",", $row["tags"]);
                        $imagePaths[] = $row["image_path"]; // Store image path

                        echo '<div class="product-card bg-white rounded-xl overflow-hidden transition duration-300 green-shadow">
                                <div class="h-48 overflow-hidden">
                                    <img src="' . $row["image_path"] . '" alt="' . $row["name"] . '"
                                        class="w-full h-full object-cover hover:scale-105 transition duration-500">
                                </div>
                                <div class="p-4">
                                    <div class="flex justify-between items-start mb-2">
                                        <h3 class="text-lg font-semibold text-green-800">' . $row["name"] . '</h3>
                                        <button onclick="deleteProduct(' . $row["id"] . ')"
                                            class="text-green-600 hover:text-green-800 transition">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </div>
                                    <p class="text-gray-600 mb-4">' . $row["description"] . '</p>
                                    <div class="flex flex-wrap mb-3">';
                                    
                                    foreach ($tags as $tag) {
                                        echo '<span class="tag">' . trim($tag) . '</span>';
                                    }
                                    
                        echo    '</div>
                                <div class="flex items-center text-green-600 location-pin">
                                    ' . $row["location"] . '
                                </div>
                            </div>
                        </div>';
                    }

                    // Print images at the bottom
                    echo '<div class="mt-10 grid grid-cols-2 md:grid-cols-4 gap-4">';
                    foreach ($imagePaths as $img) {
                        echo '<img src="' . $img . '" class="w-full h-40 object-cover rounded-lg shadow">';
                    }
                    echo '</div>';

                } else {
                    echo '<div id="emptyState" class="text-center py-12 col-span-3">
                            <i class="fas fa-seedling text-5xl text-green-400 mb-4"></i>
                            <h3 class="text-xl font-medium text-green-700 mb-2">No products yet</h3>
                            <p class="text-green-600">Add your first eco-friendly product to get started!</p>
                        </div>';
                }

                $conn->close();
                ?>

                    </div>
                </div>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const productForm = document.getElementById('productForm');
                    const productList = document.getElementById('productList');
                    const emptyState = document.getElementById('emptyState');
                    const imageInput = document.getElementById('productImage');
                    const imagePreview = document.getElementById('imagePreview');
                    const tagInput = document.getElementById('tagInput');
                    const tagSuggestions = document.getElementById('tagSuggestions');
                    const selectedTagsContainer = document.getElementById('selectedTagsContainer');
                    const productTagsInput = document.getElementById('productTags');

                    // Available tags
                    const availableTags = [
                        'Organic', 'Recycled', 'Biodegradable', 'Vegan', 
                        'Fair Trade', 'Handmade', 'Upcycled', 'Zero Waste',
                        'Sustainable', 'Eco-friendly', 'Natural', 'Renewable',
                        'Compostable', 'Energy Efficient', 'Carbon Neutral', 'Locally Sourced'
                    ];

                    let selectedTags = [];

                    // Preview image when selected
                    imageInput.addEventListener('change', function(e) {
                        const file = e.target.files[0];
                        if (file) {
                            const reader = new FileReader();
                            reader.onload = function(event) {
                                imagePreview.src = event.target.result;
                                imagePreview.style.display = 'block';
                            };
                            reader.readAsDataURL(file);
                        }
                    });

                    // Tag input functionality
                    tagInput.addEventListener('input', function() {
                        const input = tagInput.value.trim().toLowerCase();
                        if (input.length === 0) {
                            tagSuggestions.style.display = 'none';
                            return;
                        }

                        const filteredTags = availableTags.filter(tag => 
                            tag.toLowerCase().includes(input) &&
                            !selectedTags.includes(tag)
                        );

                        if (filteredTags.length > 0) {
                            tagSuggestions.innerHTML = filteredTags.map(tag => `
                                <div class="tag-suggestion" data-tag="${tag}">${tag}</div>
                            `).join('');
                            tagSuggestions.style.display = 'block';
                        } else {
                            tagSuggestions.style.display = 'none';
                            tagInput.value = ''; // Clear input if no matching tags
                        }
                    });

                    // Click outside to close suggestions
                    document.addEventListener('click', function(e) {
                        if (!tagInput.contains(e.target) && !tagSuggestions.contains(e.target)) {
                            tagSuggestions.style.display = 'none';
                        }
                    });

                    // Select tag from suggestions
                    tagSuggestions.addEventListener('click', function(e) {
                        if (e.target.classList.contains('tag-suggestion')) {
                            const tag = e.target.getAttribute('data-tag');
                            if (!selectedTags.includes(tag)) {
                                selectedTags.push(tag);
                                renderSelectedTags();
                                updateHiddenTagsInput();
                            }
                            tagInput.value = '';
                            tagSuggestions.style.display = 'none';
                        }
                    });

                    // Render selected tags
                    function renderSelectedTags() {
                        selectedTagsContainer.innerHTML = selectedTags.map(tag => `
                            <div class="tag">
                                ${tag}
                                <span class="tag-remove" data-tag="${tag}">&times;</span>
                            </div>
                        `).join('');
                    }

                    // Update hidden input with selected tags
                    function updateHiddenTagsInput() {
                        productTagsInput.value = selectedTags.join(', ');
                    }

                    // Remove tag
                    selectedTagsContainer.addEventListener('click', function(e) {
                        if (e.target.classList.contains('tag-remove')) {
                            const tag = e.target.getAttribute('data-tag');
                            selectedTags = selectedTags.filter(t => t !== tag);
                            renderSelectedTags();
                            updateHiddenTagsInput();
                        }
                    });

                    // Set tags from PHP if they exist
                    <?php if (isset($_POST['productTags']) && !empty($_POST['productTags'])): ?>
                        selectedTags = '<?php echo $_POST['productTags']; ?>'.split(', ');
                        renderSelectedTags();
                    <?php endif; ?>
                });

                function deleteProduct(id) {
                    if (confirm('Are you sure you want to delete this product?')) {
                        // AJAX request to delete product
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", "delete_product.php", true);
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        xhr.onreadystatechange = function() {
                            if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                                location.reload(); // Refresh the page
                            }
                        };
                        xhr.send("id=" + id);
                    }
                }
            </script>
        </body>
        </html>