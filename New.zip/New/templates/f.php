<?php
session_start(); // Start session to get session_id
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$product = null;
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) $product = $result->fetch_assoc();
    $stmt->close();
}

// Handle Buy Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy'])) {
    $productId = intval($_POST['product_id']);
    $sessionId = session_id();

    $stmt = $conn->prepare("INSERT INTO purchases (product_id, buyer_session_id) VALUES (?, ?)");
    $stmt->bind_param("is", $productId, $sessionId);
    $stmt->execute();
    $stmt->close();

    echo "<script>alert('Purchase recorded successfully!');</script>";
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title><?= $product ? htmlspecialchars($product['name']) : 'Product Not Found' ?> - Details</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 py-10 px-6">
<?php if ($product): ?>
  <div class="max-w-4xl mx-auto bg-white shadow rounded-lg overflow-hidden">
    <div class="flex flex-col md:flex-row">
      <div class="md:w-1/2">
        <img src="<?= htmlspecialchars($product['image_path']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-96 object-cover">
      </div>
      <div class="md:w-1/2 p-6">
        <h1 class="text-3xl font-bold mb-4"><?= htmlspecialchars($product['name']) ?></h1>
        <p class="text-gray-700 mb-4"><?= htmlspecialchars($product['description']) ?></p>
        <p class="text-sm text-gray-500 mb-2"><strong>Location:</strong> <?= htmlspecialchars($product['location']) ?></p>
        <p class="text-sm text-gray-500 mb-2"><strong>Tags:</strong> <?= htmlspecialchars($product['tags']) ?></p>
        <p class="text-xl text-green-600 font-bold mt-4">$<?= htmlspecialchars($product['price'] ?? '99.99') ?></p>

        <!-- Buy Button Form -->
        <form method="POST" class="mt-6">
          <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
          <button type="submit" name="buy"
            class="px-6 py-3 bg-green-600 text-white font-semibold rounded hover:bg-green-700 transition">
            Buy Now
          </button>
        </form>
      </div>
    </div>
  </div>
<?php else: ?>
  <div class="text-center py-20 bg-white rounded-xl shadow">
    <h2 class="text-2xl font-semibold text-gray-700">Product not found</h2>
    <p class="text-gray-500 mt-2">Invalid ID. Return to <a href="index.php" class="text-green-600">home</a>.</p>
  </div>
<?php endif; ?>
</body>
</html>
