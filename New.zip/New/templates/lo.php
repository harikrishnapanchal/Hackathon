<?php
session_start();

$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'project';

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// LOGIN
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['loginEmail'])) {
    $username = $_POST['loginEmail'];
    $password = $_POST['loginPassword'];

    $stmt = $conn->prepare("SELECT * FROM user WHERE username = ? LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $user = $res->fetch_assoc();
        if ($user['password'] === $password) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            echo "<script>window.location.href='home.html';</script>";
            exit();
        } else {
            echo "<script>alert('Incorrect password');</script>";
        }
    } else {
        echo "<script>alert('User not found');</script>";
    }
    $stmt->close();
}

// REGISTER
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registerEmail'])) {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['registerEmail'];
    $password = $_POST['registerPassword'];

    $stmt = $conn->prepare("INSERT INTO user (first_name, last_name, username, password) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $firstName, $lastName, $email, $password);

    if ($stmt->execute()) {
        echo "<script>alert('Registration successful! You can now login.');</script>";
    } else {
        echo "<script>alert('Registration failed. Maybe email already exists.');</script>";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>ReWear - Login & Register</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    .custom-shadow {
        box-shadow: 0 10px 25px -5px rgba(34, 197, 94, 0.2), 0 10px 10px -5px rgba(34, 197, 94, 0.1);
    }
    .form-transition {
        transition: all 0.3s ease-in-out;
    }
    .input-focus:focus {
        box-shadow: 0 0 0 3px rgba(34, 197, 94, 0.3);
    }
    .leaf-bg {
        background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><path fill="%2322c55d" fill-opacity="0.1" d="M30,15 Q50,5 70,15 Q90,30 85,50 Q80,70 60,85 Q40,95 30,80 Q20,65 25,50 Q30,35 30,15 Z"/></svg>');
        background-size: 300px;
        background-position: -50px -50px;
    }
  </style>
</head>
<body class="bg-gray-50 min-h-screen flex flex-col items-center justify-start p-4 leaf-bg">

  <!-- ✅ Auth Form Container -->
  <div class="container mx-auto max-w-4xl mt-6">
    <div class="flex flex-col md:flex-row rounded-xl overflow-hidden custom-shadow">
      <!-- Branding Left Box -->
      <div class="bg-green-600 text-white p-8 md:w-1/3 flex flex-col justify-center items-center text-center">
        <div class="mb-6">
          <i class="fas fa-leaf text-5xl mb-2"></i>
          <h1 class="text-3xl font-bold">ReWear</h1>
          <p class="mt-2 opacity-90">Sustainable fashion for everyone</p>
        </div>
        <div class="mt-auto">
          <p class="text-sm opacity-80">Join our community of eco-conscious people</p>
        </div>
      </div>

      <!-- Forms -->
      <div class="bg-white p-8 md:w-2/3 relative overflow-hidden">
        <div class="flex mb-8 border-b border-gray-200">
          <button id="loginBtn" class="flex-1 py-3 font-medium text-green-600 border-b-2 border-green-600">Login</button>
          <button id="registerBtn" class="flex-1 py-3 font-medium text-gray-500">Register</button>
        </div>

        <!-- Login Form -->
        <form id="loginForm" method="POST" class="form-transition">
          <h2 class="text-2xl font-bold text-gray-800 mb-6">Welcome back</h2>
          <div class="space-y-4">
            <div>
              <label for="loginEmail" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <i class="fas fa-envelope text-gray-400"></i>
                </div>
                <input name="loginEmail" type="email" id="loginEmail" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
              </div>
            </div>
            <div>
              <label for="loginPassword" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <div class="relative">
                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <i class="fas fa-lock text-gray-400"></i>
                </div>
                <input name="loginPassword" type="password" id="loginPassword" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
              </div>
            </div>
            <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium mt-4">Sign in</button>
          </div>
        </form>

        <!-- Register Form -->
        <form id="registerForm" method="POST" class="form-transition hidden">
          <h2 class="text-2xl font-bold text-gray-800 mb-6">Create an account</h2>
          <div class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label for="firstName" class="block text-sm font-medium text-gray-700 mb-1">First name</label>
                <input name="firstName" type="text" id="firstName" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
              </div>
              <div>
                <label for="lastName" class="block text-sm font-medium text-gray-700 mb-1">Last name</label>
                <input name="lastName" type="text" id="lastName" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
              </div>
            </div>
            <div>
              <label for="registerEmail" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input name="registerEmail" type="email" id="registerEmail" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label for="registerPassword" class="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input name="registerPassword" type="password" id="registerPassword" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
              </div>
              <div>
                <label for="confirmPassword" class="block text-sm font-medium text-gray-700 mb-1">Confirm password</label>
                <input type="password" id="confirmPassword" class="pl-10 w-full px-4 py-2 rounded-lg border border-gray-300 input-focus" required>
              </div>
            </div>
            <button type="submit" class="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-medium mt-4">Sign up</button>
          </div>
        </form>
      </div>
    </div>
    <p class="text-center text-gray-500 text-sm mt-6">© <?= date("Y") ?> ReWear. All rights reserved.</p>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      const loginBtn = document.getElementById('loginBtn');
      const registerBtn = document.getElementById('registerBtn');
      const loginForm = document.getElementById('loginForm');
      const registerForm = document.getElementById('registerForm');

      registerBtn.addEventListener('click', () => {
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
        loginBtn.classList.remove('text-green-600', 'border-green-600');
        loginBtn.classList.add('text-gray-500');
        registerBtn.classList.add('text-green-600', 'border-green-600');
        registerBtn.classList.remove('text-gray-500');
      });

      loginBtn.addEventListener('click', () => {
        registerForm.classList.add('hidden');
        loginForm.classList.remove('hidden');
        registerBtn.classList.remove('text-green-600', 'border-green-600');
        registerBtn.classList.add('text-gray-500');
        loginBtn.classList.add('text-green-600', 'border-green-600');
        loginBtn.classList.remove('text-gray-500');
      });
    });
  </script>
</body>
</html>
