<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

include 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($method) {
    case 'GET':
        if ($action == 'fetch_products') {
            try {
                $stmt = $pdo->query("SELECT * FROM product ORDER BY created_at DESC");
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                echo json_encode(['success' => true, 'data' => $products]);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        break;
    case 'POST':
        $input = json_decode(file_get_contents('php://input'), true);
        if ($action == 'add_product') {
            try {
                $stmt = $pdo->prepare("INSERT INTO product (title, description, category, size, condition, points, status, user) VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)");
                $stmt->execute([
                    $input['title'], $input['description'], $input['category'],
                    $input['size'], $input['condition'], $input['points'], $input['user']
                ]);
                echo json_encode(['success' => true, 'message' => 'Product added successfully']);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        if ($action == 'approve_product') {
            try {
                $stmt = $pdo->prepare("UPDATE product SET status = 'approved' WHERE id = ?");
                $stmt->execute([$input['id']]);
                echo json_encode(['success' => true, 'message' => 'Product approved']);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        if ($action == 'reject_product') {
            try {
                $stmt = $pdo->prepare("DELETE FROM product WHERE id = ?");
                $stmt->execute([$input['id']]);
                echo json_encode(['success' => true, 'message' => 'Product rejected and removed']);
            } catch(PDOException $e) {
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
            }
        }
        break;
}
?>