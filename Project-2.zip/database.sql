CREATE DATABASE IF NOT EXISTS project;
USE project;
CREATE TABLE IF NOT EXISTS product (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    category VARCHAR(100),
    size VARCHAR(20),
    condition VARCHAR(50),
    points INT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    user VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT INTO product (title, description, category, size, condition, points, status, user) VALUES
('Vintage Denim Jacket', 'Classic blue denim jacket in excellent condition', 'outerwear', 'M', 'excellent', 75, 'approved', 'Sarah M.'),
('Summer Floral Dress', 'Beautiful floral print dress, perfect for summer', 'dresses', 'S', 'good', 60, 'approved', 'Emma K.'),
('Designer Sneakers', 'Barely worn designer sneakers in white', 'shoes', '9', 'excellent', 120, 'pending', 'Mike R.');

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    points INT DEFAULT 100,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO users (username, email, password, points, is_admin) VALUES
('admin', 'admin@rewear.com', 'admin123', 500, TRUE),
('sarah', 'sarah@example.com', 'password123', 150, FALSE),
('john', 'john@example.com', 'password123', 200, FALSE);
